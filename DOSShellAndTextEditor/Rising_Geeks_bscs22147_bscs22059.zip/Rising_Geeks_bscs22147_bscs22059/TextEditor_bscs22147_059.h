#pragma once
class TextEditor
{
};

